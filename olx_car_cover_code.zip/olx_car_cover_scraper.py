#!/usr/bin/env python3
# (content same as provided earlier)
# Saved as olx_car_cover_scraper.py

import argparse
import csv
import json
import re
import sys
import time
from dataclasses import dataclass, asdict
from typing import List, Optional, Tuple
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

BASE = "https://www.olx.in"
DEFAULT_URL = "https://www.olx.in/items/q-car-cover"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}

@dataclass
class Listing:
    title: str
    price: Optional[str]
    location: Optional[str]
    date: Optional[str]
    url: str
    image: Optional[str]

def build_page_url(base_url: str, page: int) -> str:
    if page <= 1:
        return base_url
    sep = "&" if "?" in base_url else "?"
    return f"{base_url}{sep}page={page}"

def extract_text(el) -> Optional[str]:
    if not el:
        return None
    txt = el.get_text(strip=True)
    return txt or None

def parse_listings(html: str) -> List[Listing]:
    soup = BeautifulSoup(html, "html.parser")
    cards = []

    for a in soup.find_all("a", href=True):
        href = a["href"]
        if not re.search(r"/item/|/d/item/", href):
            continue

        card = a
        for _ in range(3):
            if card and card.name not in ("li", "article", "div"):
                card = card.parent
            else:
                break

        title = None
        for sel in ["[data-aut-id='itemTitle']", "h2", "h3", "span[title]", "div[title]"]:
            t = card.select_one(sel) if hasattr(card, "select_one") else None
            title = extract_text(t)
            if title:
                break
        if not title:
            title = extract_text(a)

        price = None
        for sel in ["[data-aut-id='itemPrice']", "span[data-testid='ad-price']"]:
            try:
                t = card.select_one(sel)
                price = extract_text(t)
            except Exception:
                t = None
            if price:
                break

        location, date = None, None
        for sel in ["[data-aut-id='itemDetails']", "span[data-testid='location-date']"]:
            try:
                t = card.select_one(sel)
            except Exception:
                t = None
            if t:
                parts = re.split(r"[•|·|-]+", t.get_text(" ", strip=True))
                if parts:
                    location = parts[0].strip() or None
                    if len(parts) > 1:
                        date = parts[1].strip() or None
                    break

        image = None
        img = card.find("img")
        if img and img.get("src"):
            image = img["src"]

        full_url = urljoin(BASE, href)

        if title and ("/item/" in full_url or "/d/item/" in full_url):
            cards.append(Listing(
                title=title,
                price=price,
                location=location,
                date=date,
                url=full_url,
                image=image
            ))

    seen, unique = set(), []
    for c in cards:
        if c.url in seen:
            continue
        seen.add(c.url)
        unique.append(c)

    return unique

def fetch(url: str, timeout: int = 20) -> Tuple[int, str]:
    resp = requests.get(url, headers=HEADERS, timeout=timeout)
    return resp.status_code, resp.text

def write_csv(path: str, rows: List[Listing]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["title", "price", "location", "date", "url", "image"])
        for r in rows:
            w.writerow([r.title, r.price or "", r.location or "", r.date or "", r.url, r.image or ""])

def write_json(path: str, rows: List[Listing]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump([asdict(r) for r in rows], f, ensure_ascii=False, indent=2)

def main():
    ap = argparse.ArgumentParser(description="Scrape OLX India car cover search results to CSV/JSON.")
    ap.add_argument("--base-url", default=DEFAULT_URL, help="Search URL (default is OLX 'q-car-cover')")
    ap.add_argument("--max-pages", type=int, default=3, help="How many pages to fetch")
    ap.add_argument("--delay", type=float, default=1.5, help="Delay between pages (seconds)")
    ap.add_argument("--out", default="olx_car_cover_results.csv", help="CSV output file path")
    ap.add_argument("--json", default=None, help="Optional JSON output file path")
    ap.add_argument("--verbose", action="store_true", help="Print progress")
    args = ap.parse_args()

    all_rows: List[Listing] = []

    for p in range(1, args.max_pages + 1):
        page_url = build_page_url(args.base_url, p)
        if args.verbose:
            print(f"[INFO] Fetching page {p}: {page_url}")
        status, html = fetch(page_url)
        if status != 200:
            print(f"[WARN] HTTP {status} for {page_url}", file=sys.stderr)
            break
        rows = parse_listings(html)
        if args.verbose:
            print(f"[INFO] Parsed {len(rows)} listings from page {p}")
        if not rows:
            if args.verbose:
                print("[INFO] No listings found, stopping.")
            break
        all_rows.extend(rows)
        time.sleep(args.delay)

    write_csv(args.out, all_rows)
    if args.json:
        write_json(args.json, all_rows)

    if args.verbose:
        print(f"[DONE] Wrote {len(all_rows)} rows to {args.out}" + (f" and {args.json}" if args.json else ""))

if __name__ == "__main__":
    main()
