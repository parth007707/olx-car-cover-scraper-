# OLX Car Cover Scraper

This script fetches search results from OLX India for the query **"car cover"** and saves them into a CSV file (and optional JSON).

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python olx_car_cover_scraper.py --max-pages 3 --out results.csv --json results.json --verbose
```

## Output

- `results.csv` → contains title, price, location, date, url, image link.
- `results.json` → optional JSON with the same data.
