# OLX Car Cover Search Scraper

This small script fetches search results from OLX India for the query **"car cover"** and exports them to CSV (and optionally JSON).

> Default URL used (as requested): `https://www.olx.in/items/q-car-cover`

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python olx_car_cover_scraper.py --max-pages 3 --out results.csv --json results.json --verbose
```

The script tries multiple CSS selectors to adapt to changes in OLX markup. It paginates using `?page=N` and sleeps between requests.

## Files

- `olx_car_cover_scraper.py` — the scraper.
- `requirements.txt` — dependencies.
- `results.csv` — CSV with columns: title, price, location, date, url, image.
- `results.json` — optional JSON output.

## Customization

- Change the base URL with `--base-url`, for example a city or category page that lists car covers.
- Increase `--max-pages` for more data (use responsibly).
- If you get empty results (JS-rendered pages), switch to a browser-based approach (e.g., Selenium/Playwright).

## Legal & ethical

Use this script responsibly. Respect OLX’s [Terms of Use] and robots.txt. Scraping may be restricted. Only collect data you have permission to use.

## GitHub

To put this on GitHub:

```bash
git init
git add .
git commit -m "Add OLX car cover scraper"
git branch -M main
git remote add origin https://github.com/<your-username>/olx-car-cover-scraper.git
git push -u origin main
```
